//
//#import <UIKit/UIKit.h>
//#import "PjsCallBack.h"
//#import "CallTo Parent.h"
//
//@interface ViewController : UIViewController<UITextFieldDelegate,UITableViewDataSource,UITableViewDelegate,PjsCallBack,CallTo_Parent>
//@property(nonatomic,strong)IBOutlet UITableView *lefttableView,*righttableView,*cabinetTableview;
//@end
//
