//
//  ContactUS.m
//  Proyolk
//
//  Created by Padam on 10/19/16.
//  Copyright © 2016 PURPLE. All rights reserved.
//

#import "Feedback.h"

@implementation Feedback

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
