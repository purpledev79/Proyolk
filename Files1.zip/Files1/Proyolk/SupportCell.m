//
//  SupportCell.m
//  Proyolk
//
//  Created by iFlame on 12/11/16.
//  Copyright © 2016 PURPLE. All rights reserved.
//

#import "SupportCell.h"

@implementation SupportCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
